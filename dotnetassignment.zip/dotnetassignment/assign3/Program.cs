﻿public class banner
{

public banner(int width,int height)
{
    this.width=width;
    this.height=height;
}

public virtual bool Resize(int width,int height)
{
    if(width>=height)
    {
    this.width=width;
    this.height=height;
    return true;
    }
    return false;
}

public banner():this(15,20)
{
}
private int width;
private int height;

public int Width
{
set
{
    width=value;
}
get
{
   return width;
}
}

public int Height
{
set
{
Height=value;
}
get
{
return height;
}
}


public virtual double Area()
{

    return width*height;
}


}