class inHousePatient:Patient{

private double discount;


public double Discount
{
   set
   {
    discount=value;
   }
   get
   {
    return discount;
   }

}

public inHousePatient(int Patientid,string PatientName,int bedType,int Noofdays,double discount):base(Patientid,PatientName,bedType,Noofdays)
{

 this.discount=discount;

}


public inHousePatient():base()
{
    discount=0.5;
}
// override
public override double getBillAmount()
 {
        return base.getBillAmount()*discount;
 }




}