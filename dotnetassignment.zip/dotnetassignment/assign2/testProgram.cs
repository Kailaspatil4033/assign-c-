using System;
class testProgram
{

public static void Main(string [] args){

int Patientid=int.Parse(args[0]);
String PatientName=(args[1]);
int BedType=int.Parse(args[2]);
int Noofdays=int.Parse(args[3]);

Patient t=new Patient(Patientid,PatientName,BedType,Noofdays);
//t.patient(Patientid,PatientName,BedType,Noofdays);




Console.WriteLine("amount of patient is {0}",t.getBillAmount());


inHousePatient o= new inHousePatient(Patientid,PatientName,BedType,Noofdays,0.05);

Console.WriteLine("amount for inhousepatient is {0}",o.getBillAmount());


}


}