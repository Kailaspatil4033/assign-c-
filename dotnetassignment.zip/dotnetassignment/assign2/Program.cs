﻿class Patient
{
/*public Patient()
{
    Patientid=1001;
    Patientname="jack";
    Bedtype=1;
    Noofdays=8;    
}*/

public Patient():this(112,"nikhil",1,4)
{
}

public Patient(int Patientid,String PatientName,int BedType,int Noofdays)
{

  this.Patientid=Patientid;
  this.Patientname=PatientName;
  this.Bedtype=BedType;
  this.Noofdays=Noofdays;
}


public int Patientid { get; set; }

public String Patientname { get; set; }

public int Noofdays { get; set; }

public int Bedtype { get; set;}



public double PricePerDay()
{
       double rate = 0 ;
		if(Bedtype == 1)
			rate = 500;
		if(Bedtype == 2)
			rate = 350;
		if(Bedtype == 3)
			rate = 200;
		return rate;
}

//override method..........
public virtual double  getBillAmount(){
    double amount;
    return amount=PricePerDay()*Noofdays; 
}



}



/*double rate = 0 ;
		if(bedType == 1)
			rate = 500;
		if(bedType == 2)
			rate = 350;
		if(bedType == 3)
			rate = 200;
		return rate;*/