namespace SBI;
using System;

class TestLoan
{



public static void Main(String [] args)
{
double principle=double.Parse(args[0]);

float period=float.Parse(args[1]);



Loan Pdone=new PersonalLoan(principle,period);

Console.WriteLine("Emi for personal Loan-:{0}",Pdone.GetEmi());


Loan Hdone=new HomeLoan(principle,period);

Console.WriteLine("Emi for HomeLoan-:{0}",Hdone.GetEmi());



}


}