namespace SBI;

public class PersonalLoan : Loan
{

     public PersonalLoan(double principle,float period):base(principle,period)
     {
     }
     
      public PersonalLoan():this(120000,6)
     {
     }


    public override double GetRate()
    {

        if(Principle<500000)
        return 15;
        else
        return 16;
    }
}