namespace SBI;

public class HomeLoan : Loan
{

     public HomeLoan(double principle,float period):base(principle,period)
     {
     }
     
      public HomeLoan():this(2500000,6)
     {
     }

    public override double GetRate()
    {

        if(Principle<2000000)
        return 10;
        else
        return 11;
    }
}